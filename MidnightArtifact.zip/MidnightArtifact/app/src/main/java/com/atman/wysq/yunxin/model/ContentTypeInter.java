package com.atman.wysq.yunxin.model;

/**
 * 描述
 * 作者 tangbingliang
 * 时间 16/9/2 11:39
 * 邮箱 bltang@atman.com
 * 电话 18578909061
 */
public interface ContentTypeInter {
    int contentTypeText = 0;//文本
    int contentTypeImage = 1;
    int contentTypeImageSmall = 2;
    int contentTypeAudio = 3;
    int contentTypeFinger = 4;
}
