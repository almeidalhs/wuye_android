package com.atman.wysq.iimp;

import android.view.View;

/**
 * 描述
 * 作者 tangbingliang
 * 时间 16/4/22 16:18
 * 邮箱 bltang@atman.com
 * 电话 18578909061
 */
public interface SpAdapterInterface {

    void onItemClick(View view, int position, int from);
}
