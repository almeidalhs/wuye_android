package com.atman.wysq.model.response;

/**
 * Created by tangbingliang on 17/1/18.
 */

public class LivePayMoneyModel {
    /**
     * result : 1
     * body : 1
     */

    private String result;
    private int body;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public int getBody() {
        return body;
    }

    public void setBody(int body) {
        this.body = body;
    }
}
