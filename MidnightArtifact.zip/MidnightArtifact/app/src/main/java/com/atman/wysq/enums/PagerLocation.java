package com.atman.wysq.enums;

/**
 * Created by leo on 16/5/21.
 * ViewPager所在位置
 */
public enum PagerLocation {
    LIFT,//显示页左边
    RIGHT,//显示页右边
    MIDDLE//当前显示页
}
