package com.atman.wysq.model.response;

/**
 * Created by tangbingliang on 17/1/5.
 */

public class ToLiveEorrModel {
    /**
     * result : 没有自己的直播间
     */

    private String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
