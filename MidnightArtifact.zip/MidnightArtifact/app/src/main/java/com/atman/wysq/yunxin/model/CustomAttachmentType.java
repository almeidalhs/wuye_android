package com.atman.wysq.yunxin.model;

/**
 * 描述
 * 作者 tangbingliang
 * 时间 16/9/1 20:13
 * 邮箱 bltang@atman.com
 * 电话 18578909061
 */
public interface CustomAttachmentType {
    // 多端统一
    int Guess = 1;
    int SnapChat = 2;
    int Sticker = 3;
    int RTS = 4;
}
