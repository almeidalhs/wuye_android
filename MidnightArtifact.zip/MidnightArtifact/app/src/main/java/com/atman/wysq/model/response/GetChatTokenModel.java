package com.atman.wysq.model.response;

/**
 * 描述
 * 作者 tangbingliang
 * 时间 16/8/25 14:08
 * 邮箱 bltang@atman.com
 * 电话 18578909061
 */
public class GetChatTokenModel {
    /**
     * result : 1
     * body : 04739fd479504329004085a20bcb958b
     */

    private String result;
    private String body;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
}
