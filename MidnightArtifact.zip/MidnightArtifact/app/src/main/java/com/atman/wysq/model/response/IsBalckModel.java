package com.atman.wysq.model.response;

/**
 * Created by tangbingliang on 16/12/12.
 */

public class IsBalckModel {
    /**
     * result : 1
     * body : 1
     */

    private String result;
    private int body;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public int getBody() {
        return body;
    }

    public void setBody(int body) {
        this.body = body;
    }
}
