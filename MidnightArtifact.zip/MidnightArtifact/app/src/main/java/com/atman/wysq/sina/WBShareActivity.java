package com.atman.wysq.sina;

import com.umeng.socialize.media.WBShareCallBackActivity;

/**
 * 描述
 * 作者 tangbingliang
 * 时间 16/5/4 17:14
 * 邮箱 bltang@atman.com
 * 电话 18578909061
 */
public class WBShareActivity extends WBShareCallBackActivity {
}
